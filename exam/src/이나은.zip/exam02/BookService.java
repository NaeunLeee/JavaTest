package exam02;

public interface BookService {

	public void execute(BookList list);
}
